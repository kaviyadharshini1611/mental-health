import React, { useState } from 'react';
import { 
  Home, 
  BookOpen, 
  Wind, 
  Users, 
  Phone, 
  Bell, 
  Search, 
  Menu, 
  X,
  Sparkles,
  TrendingUp,
  Calendar
} from 'lucide-react';
import { MoodTracker } from './components/mood-tracker';
import { BreathingTool } from './components/breathing-tool';
import { BlogSection } from './components/blog-section';
import { CommunityForum } from './components/community-forum';
import { ResourceDirectory } from './components/resource-directory';
import { motion, AnimatePresence } from 'framer-motion';

type Tab = 'dashboard' | 'blogs' | 'tools' | 'community' | 'resources';

const App = () => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'blogs', label: 'Expert Blogs', icon: BookOpen },
    { id: 'tools', label: 'Self-Care Tools', icon: Wind },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'resources', label: 'Help Resources', icon: Phone },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-8">
            {/* Hero Section */}
            <section className="bg-emerald-600 rounded-3xl p-8 text-white relative overflow-hidden">
              <div className="relative z-10 max-w-2xl">
                <span className="inline-flex items-center gap-2 bg-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold mb-4 backdrop-blur-sm">
                  <Sparkles className="w-3 h-3" /> Welcome back, Sarah
                </span>
                <h1 className="text-4xl font-bold mb-4">Your mental well-being matters.</h1>
                <p className="text-emerald-50 text-lg mb-6">Take a moment for yourself today. Whether it's a quick breathing exercise or sharing a thought with the community, we're here for you.</p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => setActiveTab('tools')}
                    className="bg-white text-emerald-700 px-6 py-3 rounded-xl font-bold hover:bg-emerald-50 transition-colors"
                  >
                    Start Breathing Session
                  </button>
                  <button className="bg-emerald-500/30 backdrop-blur-sm text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-500/40 transition-colors border border-emerald-400/30">
                    View My History
                  </button>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500 rounded-full opacity-50 blur-3xl" />
              <div className="absolute bottom-0 left-1/2 w-48 h-48 bg-emerald-400 rounded-full opacity-30 blur-2xl" />
            </section>

            {/* Dashboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <MoodTracker />
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-slate-800">Recommended for You</h2>
                    <button 
                      onClick={() => setActiveTab('blogs')}
                      className="text-emerald-600 font-semibold text-sm hover:underline"
                    >
                      View all
                    </button>
                  </div>
                  <BlogSection />
                </div>
              </div>
              <div className="space-y-8">
                <div className="h-full">
                   <BreathingTool />
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-emerald-500" /> Daily Tip
                  </h3>
                  <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
                    <p className="text-sm text-amber-900 leading-relaxed italic">
                      "Try the '5-4-3-2-1' technique: Name 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste. This helps ground you in the present moment."
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'blogs':
        return (
          <div className="space-y-8">
            <header>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Expert Blogs</h2>
              <p className="text-slate-500">Insights and advice from mental health professionals.</p>
            </header>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <BlogSection />
              <BlogSection /> {/* Mocking more content */}
            </div>
          </div>
        );
      case 'tools':
        return (
          <div className="space-y-8">
            <header>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Mindfulness & Self-Care</h2>
              <p className="text-slate-500">Practical tools to help you manage stress and anxiety.</p>
            </header>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="h-[400px]">
                <BreathingTool />
              </div>
              <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                  <TrendingUp className="w-8 h-8 text-blue-500" />
                </div>
                <h3 className="font-bold text-slate-900 mb-2">Guided Meditation</h3>
                <p className="text-sm text-slate-500 mb-6">Explore our library of guided sessions for sleep, focus, and anxiety.</p>
                <button className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-colors">
                  Open Library
                </button>
              </div>
              <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mb-4">
                  <Sparkles className="w-8 h-8 text-amber-500" />
                </div>
                <h3 className="font-bold text-slate-900 mb-2">Daily Gratitude</h3>
                <p className="text-sm text-slate-500 mb-6">Write down three things you are grateful for today to boost your mood.</p>
                <button className="w-full py-3 border border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors">
                  Start Journaling
                </button>
              </div>
            </div>
          </div>
        );
      case 'community':
        return (
          <div className="max-w-3xl mx-auto space-y-8">
            <header>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Community Space</h2>
              <p className="text-slate-500">A safe, moderated space to connect and share experiences.</p>
            </header>
            <CommunityForum />
          </div>
        );
      case 'resources':
        return (
          <div className="max-w-4xl mx-auto space-y-8">
            <header>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Resource Directory</h2>
              <p className="text-slate-500">Find professional help and support services near you.</p>
            </header>
            <ResourceDirectory />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b border-slate-100 p-4 sticky top-0 z-50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Sparkles className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-emerald-900">MentalHealthMatters</span>
        </div>
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
        >
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <aside className={`
          fixed lg:sticky top-0 left-0 h-screen w-64 bg-white border-r border-slate-100 p-6 z-40 transition-transform duration-300
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}>
          <div className="hidden lg:flex items-center gap-2 mb-10">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <span className="font-bold text-xl text-emerald-900">MentalHealth</span>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as Tab);
                  setIsSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === item.id 
                    ? 'bg-emerald-50 text-emerald-700' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
                }`}
              >
                <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-emerald-600' : 'text-slate-400'}`} />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="absolute bottom-6 left-6 right-6">
            <div className="bg-slate-50 p-4 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-emerald-200 flex items-center justify-center text-emerald-700 font-bold text-xs">SJ</div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold truncate">Sarah Jenkins</p>
                  <p className="text-[10px] text-slate-500">Premium Member</p>
                </div>
              </div>
              <button className="w-full py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold hover:bg-slate-50 transition-colors">
                Settings
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6 lg:p-10 max-w-7xl mx-auto w-full">
          {/* Top Bar (Desktop) */}
          <div className="hidden lg:flex items-center justify-between mb-8">
            <div className="relative w-96">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search resources, articles..."
                className="w-full bg-white border border-slate-200 rounded-xl py-2 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
              />
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
              </button>
              <button className="flex items-center gap-2 bg-white border border-slate-200 rounded-full px-4 py-2 text-sm font-semibold hover:bg-slate-50 transition-all">
                Help Center
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default App;
