import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, BookOpen, Clock } from 'lucide-react';

const blogs = [
  {
    id: 1,
    title: "Understanding Stress: Simple Techniques to Find Your Calm",
    excerpt: "Stress is a natural part of life, but learning how to manage it can significantly improve your quality of life...",
    author: "Dr. Sarah Jenkins",
    date: "Feb 5, 2026",
    readTime: "6 min read",
    image: "https://images.unsplash.com/photo-1717964134799-a98f497172a5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWxtJTIwbmF0dXJlJTIwZm9yZXN0JTIwbGFuZHNjYXBlfGVufDF8fHx8MTc3MDI2OTM2OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Anxiety"
  },
  {
    id: 2,
    title: "The Power of Mindfulness in Daily Life",
    excerpt: "Mindfulness isn't just about meditation. It's about being present in every moment, from washing dishes to working...",
    author: "Mark Thompson",
    date: "Feb 3, 2026",
    readTime: "4 min read",
    image: "https://images.unsplash.com/photo-1762828397349-d0d5f742afbc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwcGVyc29uJTIwemVuJTIwcGVhY2VmdWx8ZW58MXx8fHwxNzcwMjY5MzcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Wellness"
  }
];

export const BlogSection = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {blogs.map((blog) => (
        <article key={blog.id} className="group bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="relative h-48 overflow-hidden">
            <ImageWithFallback 
              src={blog.image} 
              alt={blog.title} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
            />
            <div className="absolute top-4 left-4">
              <span className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold text-emerald-700">
                {blog.category}
              </span>
            </div>
          </div>
          <div className="p-6">
            <div className="flex items-center gap-4 text-xs text-slate-500 mb-3">
              <span className="flex items-center gap-1"><BookOpen className="w-3 h-3" /> {blog.date}</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {blog.readTime}</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2 leading-tight group-hover:text-emerald-700 transition-colors">
              {blog.title}
            </h3>
            <p className="text-slate-600 text-sm mb-4 line-clamp-2">
              {blog.excerpt}
            </p>
            <div className="flex items-center justify-between mt-auto">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-xs">
                  {blog.author[0]}
                </div>
                <span className="text-xs font-medium text-slate-700">{blog.author}</span>
              </div>
              <button className="flex items-center gap-1 text-emerald-600 font-semibold text-sm hover:gap-2 transition-all">
                Read More <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
};
