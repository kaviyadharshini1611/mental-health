import React, { useState } from 'react';
import { MessageSquare, ThumbsUp, Share2, MoreHorizontal, User } from 'lucide-react';

const initialPosts = [
  {
    id: 1,
    user: "Alex Rivera",
    role: "Community Member",
    time: "2h ago",
    content: "Just finished my first 10-minute meditation today. I was feeling quite overwhelmed with work, but those few minutes of focus really helped clear my mind. Small wins! 🌱",
    likes: 24,
    comments: 8,
    tags: ["Mindfulness", "FirstSteps"]
  },
  {
    id: 2,
    user: "Maya Chen",
    role: "Support Advocate",
    time: "5h ago",
    content: "Does anyone have tips for dealing with social anxiety during large gatherings? My friend's birthday is coming up and I'm feeling nervous about the crowd.",
    likes: 15,
    comments: 12,
    tags: ["SocialAnxiety", "HelpNeeded"]
  }
];

export const CommunityForum = () => {
  const [posts] = useState(initialPosts);

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
        <div className="flex gap-4">
          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
            <User className="w-5 h-5 text-slate-400" />
          </div>
          <div className="flex-1">
            <textarea 
              placeholder="Share your thoughts or ask for support..."
              className="w-full bg-slate-50 border-none rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 min-h-[100px] resize-none"
            />
            <div className="mt-3 flex justify-end">
              <button className="bg-emerald-600 text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-emerald-700 transition-colors">
                Post to Community
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold">
                  {post.user[0]}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{post.user}</h4>
                  <p className="text-xs text-slate-500">{post.role} • {post.time}</p>
                </div>
              </div>
              <button className="text-slate-400 hover:text-slate-600">
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>
            
            <p className="text-slate-700 text-sm mb-4 leading-relaxed">
              {post.content}
            </p>

            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags.map(tag => (
                <span key={tag} className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50 px-2 py-1 rounded">
                  #{tag}
                </span>
              ))}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-50 text-slate-500">
              <div className="flex gap-6">
                <button className="flex items-center gap-2 hover:text-emerald-600 transition-colors">
                  <ThumbsUp className="w-4 h-4" />
                  <span className="text-xs font-medium">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 hover:text-emerald-600 transition-colors">
                  <MessageSquare className="w-4 h-4" />
                  <span className="text-xs font-medium">{post.comments}</span>
                </button>
              </div>
              <button className="hover:text-emerald-600 transition-colors">
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
