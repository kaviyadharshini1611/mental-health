import React from 'react';
import { Phone, MapPin, Globe, ExternalLink, ShieldCheck, HeartPulse } from 'lucide-react';

const resources = [
  {
    category: "Crisis Helplines",
    items: [
      {
        name: "National Suicide Prevention Lifeline",
        contact: "988",
        desc: "24/7, free and confidential support for people in distress.",
        type: "Phone",
        icon: HeartPulse
      },
      {
        name: "Crisis Text Line",
        contact: "Text HOME to 741741",
        desc: "Free, 24/7 crisis counseling via text message.",
        type: "Text",
        icon: ShieldCheck
      }
    ]
  },
  {
    category: "Therapy & Counseling",
    items: [
      {
        name: "Mindful Care Center",
        contact: "New York, NY",
        desc: "Specialized in CBT and anxiety management.",
        type: "Physical",
        icon: MapPin
      },
      {
        name: "BetterHelp Online",
        contact: "betterhelp.com",
        desc: "World's largest therapy platform, 100% online.",
        type: "Digital",
        icon: Globe
      }
    ]
  }
];

export const ResourceDirectory = () => {
  return (
    <div className="space-y-8">
      {resources.map((group) => (
        <div key={group.category}>
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <div className="w-1 h-6 bg-emerald-500 rounded-full" />
            {group.category}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {group.items.map((item) => (
              <div key={item.name} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-emerald-200 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2 bg-emerald-50 rounded-lg">
                    <item.icon className="w-5 h-5 text-emerald-600" />
                  </div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 bg-slate-50 px-2 py-1 rounded">
                    {item.type}
                  </span>
                </div>
                <h4 className="font-bold text-slate-900 mb-1">{item.name}</h4>
                <p className="text-xs text-slate-500 mb-4 leading-relaxed">{item.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-emerald-700">{item.contact}</span>
                  <button className="text-slate-400 hover:text-emerald-600 transition-colors">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="bg-emerald-600 p-8 rounded-3xl text-white overflow-hidden relative">
        <div className="relative z-10">
          <h3 className="text-2xl font-bold mb-2">Need Immediate Help?</h3>
          <p className="text-emerald-50 mb-6 max-w-md">If you are in immediate danger, please call your local emergency services (911 in the US) or go to the nearest emergency room.</p>
          <button className="bg-white text-emerald-700 px-8 py-3 rounded-full font-bold hover:bg-emerald-50 transition-colors flex items-center gap-2">
            <Phone className="w-5 h-5" /> Call Emergency Now
          </button>
        </div>
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-emerald-500 rounded-full opacity-50 blur-3xl" />
      </div>
    </div>
  );
};
