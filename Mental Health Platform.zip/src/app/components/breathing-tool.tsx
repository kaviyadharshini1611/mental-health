import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Wind } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const BreathingTool = () => {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Ready'>('Ready');
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds((prev) => (prev + 1) % 12);
      }, 1000);
    } else {
      clearInterval(interval);
      setSeconds(0);
      setPhase('Ready');
    }
    return () => clearInterval(interval);
  }, [isActive]);

  useEffect(() => {
    if (!isActive) return;
    
    if (seconds < 4) setPhase('Inhale');
    else if (seconds < 8) setPhase('Hold');
    else setPhase('Exhale');
  }, [seconds, isActive]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setSeconds(0);
    setPhase('Ready');
  };

  return (
    <div className="bg-emerald-50 p-8 rounded-2xl border border-emerald-100 flex flex-col items-center justify-center relative overflow-hidden h-full">
      <div className="absolute top-4 left-4 flex items-center gap-2 text-emerald-700">
        <Wind className="w-5 h-5" />
        <span className="font-medium">Box Breathing</span>
      </div>

      <div className="relative flex items-center justify-center w-48 h-48 mb-8">
        {/* Breathing Circle */}
        <motion.div
          animate={{
            scale: phase === 'Inhale' ? 1.5 : phase === 'Hold' ? 1.5 : 1,
            opacity: phase === 'Ready' ? 0.3 : 0.6,
          }}
          transition={{ duration: phase === 'Hold' ? 0 : 4, ease: "easeInOut" }}
          className="absolute inset-0 bg-emerald-400 rounded-full blur-xl"
        />
        <motion.div
          animate={{
            scale: phase === 'Inhale' ? 1.4 : phase === 'Hold' ? 1.4 : 1,
          }}
          transition={{ duration: phase === 'Hold' ? 0 : 4, ease: "easeInOut" }}
          className="relative z-10 w-32 h-32 bg-white rounded-full flex flex-col items-center justify-center shadow-lg border-4 border-emerald-200"
        >
          <span className="text-emerald-800 font-bold text-lg">{phase}</span>
          <AnimatePresence mode="wait">
            {isActive && (
              <motion.span
                key={seconds}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-emerald-600 text-sm font-medium"
              >
                {(seconds % 4) + 1}s
              </motion.span>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={toggleTimer}
          className="p-4 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition-colors shadow-md"
        >
          {isActive ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
        </button>
        <button
          onClick={resetTimer}
          className="p-4 bg-white text-emerald-600 rounded-full border border-emerald-200 hover:bg-emerald-50 transition-colors shadow-sm"
        >
          <RotateCcw className="w-6 h-6" />
        </button>
      </div>

      <p className="mt-6 text-sm text-emerald-700/70 text-center max-w-[200px]">
        Inhale for 4s, Hold for 4s, Exhale for 4s. Repeat as needed.
      </p>
    </div>
  );
};
