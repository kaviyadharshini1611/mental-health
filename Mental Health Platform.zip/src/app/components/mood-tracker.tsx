import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Smile, Meh, Frown, Sun, CloudRain, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

const moodData = [
  { date: 'Mon', score: 3 },
  { date: 'Tue', score: 4 },
  { date: 'Wed', score: 2 },
  { date: 'Thu', score: 5 },
  { date: 'Fri', score: 4 },
  { date: 'Sat', score: 5 },
  { date: 'Sun', score: 3 },
];

const moods = [
  { icon: Frown, label: 'Low', color: 'text-rose-500', score: 1 },
  { icon: CloudRain, label: 'Stressed', color: 'text-blue-500', score: 2 },
  { icon: Meh, label: 'Okay', color: 'text-slate-500', score: 3 },
  { icon: Smile, label: 'Good', color: 'text-emerald-500', score: 4 },
  { icon: Sun, label: 'Great', color: 'text-amber-500', score: 5 },
];

export const MoodTracker = () => {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
      <h3 className="text-xl font-semibold mb-6 text-slate-800">How are you feeling today?</h3>
      
      <div className="flex justify-between items-center mb-10">
        {moods.map((mood) => (
          <button
            key={mood.label}
            onClick={() => setSelectedMood(mood.score)}
            className={`flex flex-col items-center gap-2 transition-all p-3 rounded-xl ${
              selectedMood === mood.score 
                ? 'bg-slate-50 scale-110' 
                : 'hover:bg-slate-50'
            }`}
          >
            <mood.icon className={`w-10 h-10 ${mood.color}`} />
            <span className="text-xs font-medium text-slate-600">{mood.label}</span>
          </button>
        ))}
      </div>

      <div className="mt-8">
        <div className="flex justify-between items-center mb-4">
          <h4 className="font-medium text-slate-700">Weekly Progress</h4>
          <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded-full flex items-center gap-1">
            <Heart className="w-3 h-3 text-rose-400" /> Consistency: 7 Days
          </span>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={moodData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="date" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#64748b', fontSize: 12 }}
              />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="#10b981" 
                strokeWidth={3} 
                dot={{ fill: '#10b981', r: 4 }}
                activeDot={{ r: 6, strokeWidth: 0 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
