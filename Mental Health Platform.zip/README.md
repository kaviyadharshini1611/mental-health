
  # Mental Health Platform

  This is a code bundle for Mental Health Platform. The original project is available at https://www.figma.com/design/J0eDoUzkfvseJVUpE47IBk/Mental-Health-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  